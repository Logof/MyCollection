---
title: "Halo: The Master Chief Collection"
type: dvd
pirates: false
preview: "halo_the_master_chief_collection.jpg"
detailed: false
---