---
title: "Plants vs. Zombies Garden Warfare"
type: dvd
pirates: false
preview: "plants_vs_zombies_garden_warfare.jpg"
detailed: false
---