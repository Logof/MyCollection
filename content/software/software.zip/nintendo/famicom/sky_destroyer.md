---
title: "Sky Destroyer"
preview: "http://localhost:1313/img/software/famicom/sky_destroyer.jpg"
type: card
pirates: false
---
