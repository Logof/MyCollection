---
title: "Spider Man and Sinister Six"
preview: https://skylots.org/images/b9/49b9067fec10ca70ecc91fe960abcc6e.jpg
type: card
pirates: true
---