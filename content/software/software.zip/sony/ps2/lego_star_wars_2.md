---
title: "Lego Star Wars II"
Type: dvd
pirates: false
preview: "http://localhost:1313/img/software/ps2/lego_star_wars_2.jpg"
date: "2019-01-18"
author: "Lorem Ipsum"
---