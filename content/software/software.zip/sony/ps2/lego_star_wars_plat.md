---
title: "Lego Star Wars (Platinum)"
type: dvd
pirates: false
preview: "http://localhost:1313/img/software/ps2/lego_star_wars_plat.png"
detailed: false
---