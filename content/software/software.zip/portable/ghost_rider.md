---
title: "Ghost Rider (голыщ)"
type: psp
pirates: false
preview: "ghost_rider.jpg"
detailed: false
---