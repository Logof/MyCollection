---
title: "Echochrome"
type: psp
pirates: false
preview: "echochrome.jpg"
detailed: false
---