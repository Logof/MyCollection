---
title: "Eye Pet (с камерой)"
type: psp
pirates: false
preview: "eye_pet_with_camera.jpg"
detailed: false
---