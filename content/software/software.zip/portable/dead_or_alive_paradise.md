---
title: "Dead or Alive: Paradise"
type: psp
section: psp
pirates: false
preview: "dead_or_alive_paradise.jpg"
detailed: false
---