---
title: "Patapon 2"
type: psp
pirates: false
preview: "patapon_2.jpg"
detailed: false
---