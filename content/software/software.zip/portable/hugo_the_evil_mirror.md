---
title: "Hugo: The Evil Mirror"
type: psp
pirates: true
preview: "hugo_the_evil_mirror.jpg"
detailed: false
---