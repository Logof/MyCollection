---
title: "Grand Theft Auto: Liberty City Stories"
type: psp
pirates: false
preview: "gta_liberty_city_stories_platinum.jpg"
detailed: false
---