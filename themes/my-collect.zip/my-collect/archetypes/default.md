+++
title = "{{ replace .Name "-" " " | title }}"
date = {{ .Date }}
images = ["/2016/10/image.jpg"]
description = ""
categories = ["category"]
tags = ["tag1", "tag2"]
draft = true
+++

